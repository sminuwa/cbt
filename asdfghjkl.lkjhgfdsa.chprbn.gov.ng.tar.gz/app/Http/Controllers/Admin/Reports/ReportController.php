<?php

namespace App\Http\Controllers\Admin\Reports;

use App\Http\Controllers\Controller;
use App\Models\Candidate;
use App\Models\Centre;
use App\Models\Score;
use App\Models\Subject;
use App\Models\TestConfig;
use App\Models\TestQuestion;
use App\Models\TestSubject;
use Illuminate\Database\Query\JoinClause;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function index()
    {
        return view('pages.admin.reports.index');
    }

    public function testReports()
    {
        return view('pages.admin.reports.test-reports');
    }

    public function reportSummary()
    {
        $years = TestConfig::select('session')->groupBy('session')->orderBy('session', 'desc')->get()->pluck('session');
        $centres = Centre::orderBy('name','asc')->get();
        $subjects = Subject::orderBy('subject_code')->get();
        return view('pages.admin.reports.report-summary', compact('years', 'centres', 'subjects'));
    }

    public function generateReport(Request $request)
    {
        try {
            // Get all subjects dynamically from the database or filter by selected subject
            $allSubjects = Subject::orderBy('subject_code')->get();
            $subject_id = $request->subject_id;
            
            if ($subject_id && $subject_id !== 'all') {
                // Filter for specific subject
                $subjects = $allSubjects->where('id', $subject_id);
            } else {
                // Use all subjects
                $subjects = $allSubjects;
            }
            
            $centre_id = $request->centre_id;
            $year = $request->year;
            $code_id = $request->code_id;
            $type_id = $request->type_id;
            
            // Safety check: if no subjects exist, return empty result
            if ($subjects->isEmpty()) {
                $candidates = collect();
                $statistics = (object)[];
                $percentages = (object)[
                    'below_50' => 0,
                    'above_50' => 0,
                    'total' => 0,
                ];
                return view('pages.admin.reports.ajax.report-summary', compact('candidates', 'subjects','statistics','percentages'));
            }
            
            // Build dynamic CASE statements for each subject with SQL injection protection
            $subjectCases = [];
            foreach($subjects as $subject) {
                // Escape subject code to prevent SQL injection
                $escapedSubjectCode = DB::connection()->getPdo()->quote($subject->subject_code);
                $columnAlias = 'subject_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $subject->subject_code); // Create safe column alias
                $subjectCases[] = "SUM(CASE WHEN subjects.subject_code = {$escapedSubjectCode} THEN scores.point_scored ELSE 0 END) AS {$columnAlias}";
            }
            $subjectCasesString = implode(',
                ', $subjectCases);
            
            $candidatesQuery = Candidate::selectRaw("
                CONCAT(candidates.surname, ' ', candidates.firstname, ' ', IFNULL(candidates.other_names, '')) AS fullname,
                candidates.indexing AS indexing,
                scheduled_candidates.id AS scheduled_candidate_id,
                candidates.id AS candidate_id,
                test_configs.id AS test_config_id,
                centres.name AS centre,
                {$subjectCasesString},
                candidates.exam_year as year
            ")
            ->join('scheduled_candidates', 'scheduled_candidates.candidate_id', '=', 'candidates.id')
            ->join('candidate_subjects', 'candidate_subjects.scheduled_candidate_id', '=', 'scheduled_candidates.id')
            ->join('schedulings', 'schedulings.id', '=', 'scheduled_candidates.schedule_id')
            ->join('test_configs', 'test_configs.id', '=', 'schedulings.test_config_id')
            ->join('venues', 'venues.id', '=', 'schedulings.venue_id')
            ->join('centres', 'centres.id', '=', 'venues.centre_id')
            ->leftJoin('scores', 'scores.scheduled_candidate_id', '=', 'scheduled_candidates.id')
            ->leftJoin('subjects', 'subjects.id', '=', 'candidate_subjects.subject_id')
            ->where([
                'centres.id' => $centre_id,
                'candidates.exam_year' => $year,
                'test_configs.test_code_id' => $code_id,
                'test_configs.test_type_id' => $type_id,
            ]);
            
            // Add subject filter if specific subject is selected
            if ($subject_id && $subject_id !== 'all') {
                $candidatesQuery->whereExists(function($query) use ($subject_id) {
                    $query->select(DB::raw(1))
                          ->from('candidate_subjects as cs')
                          ->whereRaw('cs.scheduled_candidate_id = scheduled_candidates.id')
                          ->where('cs.subject_id', $subject_id);
                });
            }
            
            $candidates = $candidatesQuery->groupBy('candidates.id')->get();
            
            // Build dynamic statistics array
            $statistics = [];
            foreach($subjects as $subject) {
                $statistics[$subject->subject_code . '_below_50_count'] = 0;
                $statistics[$subject->subject_code . '_above_50_count'] = 0;
            }

            // Calculate statistics dynamically
            foreach($candidates as $candidate) {
                // Process subject scores
                foreach($subjects as $subject) {
                    $subjectCode = $subject->subject_code;
                    $columnAlias = 'subject_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $subject->subject_code); // Same sanitization as in query
                    $score = $candidate->{$columnAlias} ?? 0;
                    
                    if($score < 50 && $score > 0) {
                        $statistics[$subjectCode . '_below_50_count']++;
                    }
                    if($score >= 50) {
                        $statistics[$subjectCode . '_above_50_count']++;
                    }
                }
            }

            $statistics = (object)$statistics;
            
            // Calculate percentages dynamically
            $totalAbove50 = 0;
            $totalBelow50 = 0;
            
            foreach($subjects as $subject) {
                $subjectCode = $subject->subject_code;
                $totalAbove50 += $statistics->{$subjectCode . '_above_50_count'};
                $totalBelow50 += $statistics->{$subjectCode . '_below_50_count'};
            }
            
            $percentages = [
                'below_50' => $totalBelow50,
                'above_50' => $totalAbove50,
                'total' => count($candidates),
            ];
            $percentages = (object)$percentages;
            // return $statistics;
            // return $statistics;
            // $candidates = Candidate::selectRaw("
            //     CONCAT(candidates.surname,' ', candidates.firstname,' ', IFNULL(candidates.other_names, '')) as fullname,
            //     candidates.indexing as indexing,
            //     scheduled_candidates.id as scheduled_candidate_id,
            //     candidate_id,
            //     test_configs.id as test_config_id,
            //     centres.name as centre,
            //     (
            //         SELECT sum(s.point_scored) 
            //         FROM scores s
            //         JOIN scheduled_candidates sc ON sc.id = s.scheduled_candidate_id
            //         JOIN candidates c ON c.id = sc.candidate_id
            //         JOIN candidate_subjects cs ON cs.scheduled_candidate_id = sc.id
            //         JOIN subjects sj ON sj.id = cs.subject_id
            //         WHERE c.id = candidates.id
            //         AND sj.subject_code = 'P1'
            //     ) as P1,
            //     (
            //         SELECT sum(s.point_scored) 
            //         FROM scores s
            //         JOIN scheduled_candidates sc ON sc.id = s.scheduled_candidate_id
            //         JOIN candidates c ON c.id = sc.candidate_id
            //         JOIN candidate_subjects cs ON cs.scheduled_candidate_id = sc.id
            //         JOIN subjects sj ON sj.id = cs.subject_id
            //         WHERE c.id = candidates.id
            //         AND sj.subject_code = 'P2'
            //     ) as P2,
            //     (
            //         SELECT sum(s.point_scored) 
            //         FROM scores s
            //         JOIN scheduled_candidates sc ON sc.id = s.scheduled_candidate_id
            //         JOIN candidates c ON c.id = sc.candidate_id
            //         JOIN candidate_subjects cs ON cs.scheduled_candidate_id = sc.id
            //         JOIN subjects sj ON sj.id = cs.subject_id
            //         WHERE c.id = candidates.id
            //         AND sj.subject_code = 'P3'
            //     ) as P3,
            //     (
            //         SELECT sum(pe.score) 
            //         FROM practical_examinations pe
            //         WHERE pe.candidate_id = candidates.id
            //     ) AS PE,
            //     (
            //         SELECT sum(pa.score) 
            //         FROM project_assessments pa
            //         WHERE pa.candidate_id = candidates.id
            //     ) AS PA

            // ")
            // ->join('scheduled_candidates','scheduled_candidates.candidate_id', 'candidates.id')
            // ->join('candidate_subjects', 'candidate_subjects.scheduled_candidate_id', 'scheduled_candidates.id')
            // ->join('schedulings', 'schedulings.id', 'scheduled_candidates.schedule_id')
            // ->join('test_configs','test_configs.id', 'schedulings.test_config_id')
            // ->join('venues','venues.id', 'schedulings.venue_id')
            // ->join('centres','centres.id', 'venues.centre_id')    
            // ->where([
            //     'centres.id'=>$centre_id,
            //     'candidates.exam_year'=>$year,
            //     'test_configs.test_code_id'=>$code_id,
            //     'test_configs.test_type_id'=>$type_id
            // ])
            // ->groupBy('candidates.id')
            // ->get();

            // $candidates = Candidate::all();
            // return $candidates;
            // return $scores;
            // // return $titles;

            // $candidates = Candidate::select('candidates.indexing', 'candidates.firstname', 'candidates.surname', 'candidates.other_names')
            //     ->join('scheduled_candidates', 'candidates.id', '=', 'scheduled_candidates.candidate_id')
            //     ->join('candidate_subjects', 'scheduled_candidates.id', '=', 'candidate_subjects.scheduled_candidate_id')
            //     ->join('subjects', 'candidate_subjects.subject_id', '=', 'subjects.id')
            //     ->join('scores', 'scores.scheduled_candidate_id', '=', 'scheduled_candidates.id')
            //     ->join('question_banks', 'scores.question_bank_id', '=', 'question_banks.id')
            //     ->join('test_configs', 'scores.test_config_id', '=', 'test_configs.id')
            //     ->where('test_config_id', $request->test_config_id)
            //     ->groupBy('candidates.indexing')
            //     ->get();

            // return $candidates;

            // $reports = [];
            // foreach ($candidates as $candidate) {
            //     $candidateData = [
            //         'indexing' => $candidate->indexing,
            //         'surname' => $candidate->surname,
            //         'firstname' => $candidate->firstname,
            //         'other_names' => $candidate->other_names,
            //     ];

            //     foreach ($subjects as $subject) {
            //         $score = DB::table('scores')
            //             ->join('candidate_subjects', 'scores.scheduled_candidate_id', '=', 'candidate_subjects.scheduled_candidate_id')
            //             ->join('subjects', 'candidate_subjects.subject_id', '=', 'subjects.id')
            //             ->join('test_configs', 'scores.test_config_id', '=', 'test_configs.id')
            //             ->where('subjects.name', $subject)
            //             ->where('scores.scheduled_candidate_id', $candidate->scheduled_candidate_id)
            //             ->select(DB::raw('(scores.point_scored / test_configs.total_mark) * 100 as percentage'))
            //             ->value('percentage');
            //         $candidateData[$subject] = $score ? number_format($score, 2) . '%' : '';
            //     }

            //     $reports[] = $candidateData;
            // }

            return view('pages.admin.reports.ajax.report-summary', compact('candidates', 'subjects','statistics','percentages'));
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    public function questionSummary()
    {
        $configs = $this->tests();

        return view('pages.admin.reports.question-summary', compact('configs'));
    }

    public function generateQuestionSummary(Request $request)
    {
        try {
            $where = [];
            $subject_id = $request->test_subject_id;
            $config_id = $request->test_config_id;

            if ($subject_id != '%')
                $where[] = ['subject_id', $subject_id];

            $where[] = ['test_config_id', $config_id];

            $report = [];

            $subjects = TestSubject::with('subject')->where($where)->get()->pluck('subject');
            foreach ($subjects as $subject) {
                $obj = [];
                $questions = TestQuestion::with('question_bank')
                    ->join('test_sections', 'test_sections.id', '=', 'test_questions.test_section_id')
                    ->join('test_subjects', 'test_subjects.id', '=', 'test_sections.test_subject_id')
                    ->select('question_bank_id')
                    ->where([
                        'test_subjects.test_config_id' => $config_id,
                        'subject_id' => $subject->id
                    ])
                    ->get();

                $qtns = [];
                foreach ($questions as $q) {
                    $qtnStat = [];
                    $question = $q->question_bank;
                    $options = $q->question_bank->answer_options;
                    $counts = DB::table('presentations')
                        ->select(DB::raw('count(distinct scheduled_candidate_id) as presented'))
                        ->where(['test_config_id' => $config_id, 'question_bank_id' => $question->id])
                        ->pluck('presented')->first();

                    $qtnStat['id'] = $question->id;
                    $qtnStat['presented'] = $counts;

                    $correct = 0;
                    $optionStat = [];
                    foreach ($options as $option) {
                        $stat = [];
                        $stat['correct'] = 0;
                        if ($option->correctness == 1) {
                            $correct = $option->id;
                            $stat['correct'] = 1;
                        }

                        $counts = DB::table('scores')
                            ->select(DB::raw('count(*) as total'))
                            ->where(['test_config_id' => $config_id, 'answer_option_id' => $option->id])
                            ->pluck('total')->first();

                        $stat['option'] = $option->question_option;
                        $stat['count'] = $counts;

                        $optionStat[] = $stat;
                    }

                    $failed = 0;
                    if ($correct !== 0) {
                        $counts = DB::table('scores')
                            ->select(DB::raw('count(distinct scheduled_candidate_id) as correct'))
                            ->where(['test_config_id' => $config_id, 'question_bank_id' => $question->id, 'answer_option_id' => $correct])
                            ->pluck('correct')->first();
                        $correct = $counts;

                        $counts = DB::table('scores')
                            ->select(DB::raw('count(distinct scheduled_candidate_id) as correct'))
                            ->where(['test_config_id' => $config_id, 'question_bank_id' => $question->id])
                            ->where('answer_option_id', '<>', $correct)
                            ->pluck('correct')->first();
                        $failed = $counts;
                    }

                    $qtnStat['failed'] = $failed;
                    $qtnStat['passed'] = $correct;
                    $qtnStat['options'] = $optionStat;
                    $qtnStat['question'] = $question->title;
                    $qtnStat['no_count'] = $qtnStat['presented'] - ($failed + $correct);

                    $qtns[] = $qtnStat;
                }

                $obj['subject'] = $subject->subject_code . ' - ' . $subject->name;
                $obj['questions'] = $qtns;

                $report[] = $obj;
            }

            //return $report;

            return view('pages.admin.reports.ajax.question-summary', compact('report'));
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    public function presentationSummary()
    {
        $configs = $this->tests();

        return view('pages.admin.reports.presentation-summary', compact('configs'));
    }

    public function generatePresentationSummary(Request $request)
    {
        try {
            $config = $request->test_config_id;
            $candidatesIds = $request->candidates;

            $testSubjects = TestSubject::with('subject')
                ->select('subject_id')
                ->where('test_config_id', $config)
                ->get();

            $subjects = [];
            foreach ($testSubjects as $testSubject)
                $subjects[] = $testSubject->subject;


            $candidates = Candidate::select('id', 'indexing', 'surname', 'firstname', 'other_names')
                ->whereIn('id', $candidatesIds)
                ->get();

            return view('pages.admin.reports.ajax.presentation-summary', compact('candidates', 'subjects', 'config'));

            /*
            foreach ($candidates as $candidate) {
                foreach ($subjects as $subject) {
                    $sections = TestSection::select('id', 'title', 'instruction')
                        ->where('test_subject_id', $subject->id)->get();

                    foreach ($sections as $section) {
                        $questions = DB::table('presentations')
                            ->join('test_sections', 'test_sections.id', '=', 'presentations.test_section_id')
                            ->join('question_banks', 'question_banks.id', '=', 'presentations.question_bank_id')
                            ->join('test_subjects', 'test_subjects.id', '=', 'test_sections.test_subject_id')//
                            ->select('question_banks.id', 'question_banks.title as question')
                            ->where([
                                'test_sections.id' => $section->id,
                                'presentations.test_config_id' => $config,
                                'presentations.scheduled_candidate_id' => $candidate->id
                            ])
                            ->distinct('presentations.question_bank_id')
                            ->get();

                        foreach ($questions as $question) {
                            $options = AnswerOption::select('id', 'question_option as option', 'correctness')
                                ->where('question_bank_id', $question->id)->get();
                            $selection = Score::select('answer_option_id as selection')
                                ->where([
                                    'test_config_id' => $config,
                                    'question_bank_id' => $question->id,
                                    'scheduled_candidate_id' => $candidate->id
                                ])
                                ->pluck('selection')->first();

                            $question->selection = $selection;
                            $question->options = $options;
                        }

                        $section['questions'] = $questions;
                    }

                    $subject['sections'] = $sections;
                }
                $candidate['subjects'] = $subjects;
            }

            return $candidate;
            */
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    public function activeCandidates()
    {
        $exams = TestConfig::exam()->get();
        return view('pages.admin.reports.active-candidates', compact('exams'));
    }

    public function daily()
    {
        return view('pages.admin.reports.test-reports');
    }

    public function generateActiveCandidates(Request $request)
    {
        try {
            $test_config_id  = $request->test_config_id;
            // $actives = DB::table('time_controls')
            //     ->join('candidates', 'candidates.id', '=', 'time_controls.scheduled_candidate_id')
            //     ->select(
            //         'indexing',
            //         'time_controls.id AS eid',
            //         'scheduled_candidate_id',
            //         DB::raw('concat(candidates.surname," ",candidates.firstname," ",candidates.other_names) as name'),
            //         'ip as address'
            //     )
            //     ->where(['test_config_id' => $request->test_config_id, 'completed' => 0])
            //     ->get();
            // return $test_config_id;
            $candidates =  Candidate::manage($test_config_id)->get();
            
        return view('pages.admin.toolbox.ajax.active', compact('candidates'));
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    public function generateDaily(Request $request)
    {
        return $request;
    }


    private function tests()
    {
        return TestConfig::with(['test_type', 'test_code'])
            ->select(['id', 'session', 'semester', 'test_type_id', 'test_code_id'])
            ->orderBy('session', 'desc')
            ->get();
    }
}
