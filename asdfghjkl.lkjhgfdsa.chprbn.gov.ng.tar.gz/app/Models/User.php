<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

//use Laravel\Sanctum\HasApiTokens;

/**
 * Class User
 *
 * @property int $id
 * @property string $username
 * @property string $password
 * @property string $display_name
 * @property string $email
 * @property string $personnel_no
 * @property int $enabled
 * @property string $question
 * @property string $answer
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 *
 * @property Collection|TestCompositor[] $test_compositors
 * @property Collection|TestConfig[] $test_configs
 * @property Collection|TestInvigilator[] $test_invigilators
 * @property Collection|Permission[] $permissions
 * @property Collection|Role[] $roles
 *
 * @package App\Models
 */
class User extends Authenticatable
{
    use  HasFactory, Notifiable;

    protected $table = 'users';

    protected $casts = [
        'enabled' => 'int'
    ];

    protected $hidden = [
        'password'
    ];

    protected $guarded = [];

    public function test_compositors()
    {
        return $this->hasMany(TestCompositor::class);
    }

    public function compositor_subjects()
    {
        return $this->belongsToMany(Subject::class, 'test_compositors', 'user_id', 'subject_id')
            ->withPivot('test_config_id');
    }

    public function previewer_subjects()
    {
        return $this->belongsToMany(Subject::class, 'question_previewers', 'user_id', 'subject_id')
            ->withPivot('test_config_id');
    }

    public function test_configs()
    {
        return $this->hasMany(TestConfig::class, 'initiated_by');
    }

    public function test_invigilators()
    {
        return $this->hasMany(TestInvigilator::class);
    }

    public function permissions()
    {
        return $this->belongsToMany(Permission::class, 'user_permissions')
            ->withPivot('id')
            ->withTimestamps();
    }

    public function roles()
    {
        return $this->belongsToMany(Role::class, 'user_roles')
            ->withPivot('id')
            ->withTimestamps();
    }


    public function canDo($permission){
        $permissionObj = Permission::where('name',$permission)->first();
        if($permissionObj){
            $userRoles = UserRole::where(['user_id'=>$this->id])->pluck('role_id');
            return $rolePermissions = RolePermission::where(['permission_id'=>$permissionObj->id])->whereIn('role_id',$userRoles)->count();
        }
        return true;
    }
}
