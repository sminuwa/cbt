<!-- jQuery -->
<script src="{{asset("assets/js/jquery-3.7.1.min.js")}}"></script>

<!-- Bootstrap Core JS -->
<script src="{{asset("assets/js/bootstrap.bundle.min.js")}}"></script>

<!-- Sticky Sidebar JS -->
<script src="{{asset("assets/plugins/theia-sticky-sidebar/ResizeSensor.js")}}"></script>
<script src="{{asset("assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js")}}"></script>

<!-- Apex JS -->
<script src="{{asset("assets/plugins/apex/apexcharts.min.js")}}"></script>

<!-- Custom JS -->
<script src="{{asset("assets/js/script.js")}}"></script>

<script src="{{asset("assets/js/jquery.ui.git.js")}}"></script>


