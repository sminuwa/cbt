@extends('layouts.candidate')

@section('content')


@endsection

@push('style')


@endpush

@push('script')

@endpush
