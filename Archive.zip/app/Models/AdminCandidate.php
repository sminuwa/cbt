<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdminCandidate extends Model
{
    use HasFactory;
    protected $guarded = [];
}
